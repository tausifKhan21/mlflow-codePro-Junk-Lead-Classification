# You can create more variables according to your project. The following are the basic variables that have been provided to you
DB_PATH = '/home/Assignment/01_data_pipeline/scripts/unit_test/'
DB_FILE_NAME = r'utils_output.db' 
TEST_DB_FILE_NAME = r'unit_test_cases.db' 
DATA_DIRECTORY = '/home/Assignment/01_data_pipeline/scripts/unit_test/'
INTERACTION_MAPPING = '/home/Assignment/01_data_pipeline/scripts/unit_test/'
INDEX_COLUMNS = ['created_date', 'first_platform_c', 'first_utm_medium_c', 'first_utm_source_c', 'total_leads_droppped', 'city_tier', 'referred_lead', 'app_complete_flag']
#NOT_FEATURES = 
#UNIT_TEST_DB_FILE_NAME = 
